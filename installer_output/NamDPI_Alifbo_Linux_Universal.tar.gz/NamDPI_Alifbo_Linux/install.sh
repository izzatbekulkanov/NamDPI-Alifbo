#!/bin/bash
# NamDPI alifbo - Universal Linux Installer
# Namangan davlat pedagogika instituti RTTM

set -e

if [ "$EUID" -ne 0 ]; then
  echo "Iltimos, o'rnatish uchun sudo bilan ishga tushiring:"
  echo "  sudo ./install.sh"
  exit 1
fi

echo "=========================================================="
echo " NamDPI alifbo - Linux tizimiga o'rnatilmoqda..."
echo " Namangan davlat pedagogika instituti RTTM"
echo "=========================================================="

APP_DIR="/opt/namdpi-alifbo"
mkdir -p "$APP_DIR"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR/src/"* "$APP_DIR/"
chmod +x "$APP_DIR/main.py"

# Launcher
cat << 'EOF' > /usr/local/bin/namdpi-alifbo
#!/bin/sh
exec python3 /opt/namdpi-alifbo/main.py "$@"
EOF
chmod +x /usr/local/bin/namdpi-alifbo

# Icon
mkdir -p /usr/share/icons/hicolor/256x256/apps/
cp "$APP_DIR/app_icon.png" /usr/share/icons/hicolor/256x256/apps/namdpi-alifbo.png

# Desktop entry
cat << 'EOF' > /usr/share/applications/namdpi-alifbo.desktop
[Desktop Entry]
Type=Application
Name=NamDPI alifbo
GenericName=Alifbo Konverteri
Comment=Namangan davlat pedagogika instituti Alifbo Konverteri
Exec=/usr/local/bin/namdpi-alifbo
Icon=namdpi-alifbo
Terminal=false
Categories=Utility;Education;TextTools;
StartupNotify=true
EOF

# Pip packages
echo "Kerakli python kutubxonalari tekshirilmoqda..."
pip3 install pynput pystray Pillow --break-system-packages 2>/dev/null || pip3 install pynput pystray Pillow 2>/dev/null || true

if which update-desktop-database >/dev/null 2>&1; then
    update-desktop-database -q || true
fi

echo ""
echo "=========================================================="
echo " MUVAFFAQIYATLI O'RNATILDI!"
echo " Dasturni ishga tushirish:"
echo "   namdpi-alifbo"
echo " yoki Ilovalar menyusidan 'NamDPI alifbo' ni bosing."
echo "=========================================================="

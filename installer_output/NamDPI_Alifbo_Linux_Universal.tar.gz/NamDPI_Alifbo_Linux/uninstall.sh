#!/bin/bash
# NamDPI alifbo - Linux Uninstaller
set -e
if [ "$EUID" -ne 0 ]; then
  echo "sudo bilan ishga tushiring: sudo ./uninstall.sh"
  exit 1
fi

pkill -f "namdpi-alifbo" || true
rm -rf /opt/namdpi-alifbo
rm -f /usr/local/bin/namdpi-alifbo
rm -f /usr/share/applications/namdpi-alifbo.desktop
rm -f /usr/share/icons/hicolor/256x256/apps/namdpi-alifbo.png

if which update-desktop-database >/dev/null 2>&1; then
    update-desktop-database -q || true
fi

echo "NamDPI alifbo to'liq o'chirildi."

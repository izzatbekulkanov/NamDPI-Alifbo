# NamDPI alifbo

**Namangan davlat pedagogika instituti**  
**Raqamli taʼlim texnologiyalari markazi (NamDPI RTTM)** tomonidan ishlab chiqilgan professional dasturiy taʼminot.

---

## 📌 Dastur haqida

**"NamDPI alifbo"** — kompyuterda (Windows 10 va Windows 11 tizimlarida) istalgan matn muharririda (**Microsoft Word, Telegram, Notepad, Brauzerlar, Excel** va barcha dasturlarda) matn terayotganda soʻzlarni probel (boʻsh joy) yoki tinish belgisi bosilishi bilan avtomatik ravishda tanlangan alifboga tezkor va xatosiz oʻgirib beruvchi professional dastur.

### 🌟 Asosiy imkoniyatlar:
1. **Yangi Oʻzbek Lotin alifbosi (2026):**
   - `sh` $\rightarrow$ `ş` (masalan: `shabnam` $\rightarrow$ `şabnam`, `shanba` $\rightarrow$ `şanba`)
   - `ch` $\rightarrow$ `ç` (masalan: `choy` $\rightarrow$ `çoy`)
   - `oʻ` / `o'` $\rightarrow$ `ö` (masalan: `o'zbekiston` $\rightarrow$ `özbekiston`, `o'quvchi` $\rightarrow$ `öquvçi`)
   - `gʻ` / `g'` $\rightarrow$ `ğ` (masalan: `bog'` $\rightarrow$ `boğ`, `g'alaba` $\rightarrow$ `ğalaba`)
   - Katta va bosh harflar toʻliq saqlanadi (`Shabnam` $\rightarrow$ `Şabnam`, `SHAHAR` $\rightarrow$ `ŞAHAR`).
2. **Oʻzbek Kirill alifbosi:**
   - `shanba` $\rightarrow$ `шанба`, `shabnam` $\rightarrow$ `шабнам`, `o'zbek` $\rightarrow$ `ўзбек`, `bog'` $\rightarrow$ `боғ`
   - Soʻz boshida `e` $\rightarrow$ `э`, undoshdan keyin `e` $\rightarrow$ `е`, `s'h` $\rightarrow$ `сҳ` (`Is'hoq` $\rightarrow$ `Исҳоқ`), tutuq belgilari `’` $\rightarrow$ `ъ` (`ma'no` $\rightarrow$ `маъно`).
3. **Amaldagi Lotin alifbosi (1995):**
   - Kirill yoki Yangi Lotindagi matnni standart Lotin (`sh`, `ch`, `oʻ`, `gʻ`) formatiga qaytarish.
4. **Oʻchirilgan (Bypass) rejim:**
   - Inglizcha matn yoki kod yozayotganda avto-almashtirishni vaqtincha toʻxtatish.
5. **Pastki Qatordagi Professional Panel (Taskbar Dock Panel):**
   - Ekranning oʻrtasida xalal bermaydi, pastki qatorda (Taskbar ustida, soat va til indikatori yonida) ixcham va chiroyli turadi.
   - Ixchamlashtirish imkoniyati: mini-kapsula rejimiga oʻtkazish mumkin.
   - Windows 11 Fluent Design talablariga mos zamonaviy quyuq (dark) interfeys.
6. **Dinamik Tizim Tepsisi (System Tray):**
   - Pastdagi Taskbar burchagida qaysi alifbo faolligiga qarab **`Ö`**, **`Ў`**, **`Oʻ`**, **`OFF`** belgilari aniq koʻrinib turadi.
7. **Tezkor klavishlar (Hotkeys):**
   - **`F8`** yoki **`Ctrl + Shift + U`** — sichqonchaga tegmasdan turib alifbo rejimini klaviaturaning oʻzidan zumda almashtirish.

---

## 🚀 Oʻrnatish (Installer)

Tayyor Windows oʻrnatuvchi dastur:  
📁 **`I:\translate\installer_output\NamDPI_Alifbo_Setup.exe`**

Oʻrnatuvchi yordamida:
- Dastur kompyuterga rasmiy oʻrnatiladi.
- Ish stolida va Bosh menyuda **"NamDPI alifbo"** yorligʻi paydo boʻladi.
- Kompyuter yoqilganda avtomatik ishga tushish sozlamasi faollashadi.
